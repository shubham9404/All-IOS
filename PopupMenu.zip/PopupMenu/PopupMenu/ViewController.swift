//
//  ViewController.swift
//  PopupMenu
//
//  Created by student14 on 18/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBOutlet var bOuletCollection: [UIButton]!
    
    @IBAction func bAction(_ sender: Any) {
        bOuletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
            
        }
    }
    
    @IBAction func button1(_ sender: Any) {
        let nextp = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        navigationController?.pushViewController(nextp, animated: true)
    }
    
    @IBAction func button2(_ sender: Any) {
        let nextp2 = storyboard?.instantiateViewController(withIdentifier: "NextViewController2") as! NextViewController2
        navigationController?.pushViewController(nextp2, animated: true)
    }
    
    
}

