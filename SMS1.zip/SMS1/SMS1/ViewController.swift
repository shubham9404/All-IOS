//
//  ViewController.swift
//  SMS1
//
//  Created by student14 on 21/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var text: UITextField!
    
    @IBOutlet weak var leb: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func Add(_ sender: UIButton) {
        leb.text = text.text
    }
    
    @IBAction func next(_ sender: Any) {
        let nextb=storyboard?.instantiateViewController(withIdentifier: "nextViewController") as! nextViewController; navigationController?.pushViewController(nextb, animated: true)
    }
    
}

