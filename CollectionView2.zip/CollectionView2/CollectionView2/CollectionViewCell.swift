//
//  CollectionViewCell.swift
//  CollectionView2
//
//  Created by student14 on 10/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var numberLable: UILabel!
}
