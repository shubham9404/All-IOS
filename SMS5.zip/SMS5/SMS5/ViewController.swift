//
//  ViewController.swift
//  SMS5
//
//  Created by student14 on 23/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seg"
        {
            let next = segue.destination as! NextViewController
            next.name = textt.text!
        }
        
    }

}

