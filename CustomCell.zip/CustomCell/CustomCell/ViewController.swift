//
//  ViewController.swift
//  CustomCell
//
//  Created by student14 on 10/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var nameArray = ["Shubham","Pratik","Akshay","Swami"]
    
    func tableView(_ tableview: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = nameArray[indexPath.row]
        let switch1 = UISwitch()
        cell.accessoryView = switch1
        switch1.accessibilityLabel = cell.textLabel?.text
        switch1.addTarget(self, action: #selector(handleSwitch(sender:)), for: .valueChanged)
        return cell
    }
    @objc func handleSwitch(sender:UISwitch)
    {
        if sender.isOn
        {
            print("Switch is on")
            print(sender.accessibilityLabel!)
        }
        else
        {
            print("Switch is off")
        }
    }
    
    func numberOfSections(in tableview: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }


}

