//
//  hospitalDB.swift
//  HospitalDataBase
//
//  Created by Shubham Shinde on 15/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import Foundation
import SQLite3

class hospitalDB
{
    var taskPatientArray = [String]()
    var taskDoctorArray = [String]()
    var taskWardArray = [String]()
    
    static let sharedObject = hospitalDB()
    
    func getDataBasePath() -> String
    {
        let direction = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = direction.first!
        return path+"DBHospital.sqlite"
    }
    
    
    
    func executeQuery(query:String)-> Bool
    {
        var success = false
        var db:OpaquePointer?
        var stmt:OpaquePointer?
        let path = getDataBasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stmt, nil) == SQLITE_OK
            {
                if sqlite3_step(stmt!) == SQLITE_DONE
                {
                    success = true
                    sqlite3_finalize(stmt!)
                    sqlite3_close(db)
                }
            }
            else
            {
                print("Error in prepare:\(sqlite3_step(stmt!))")
            }
        }
        else
        {
            print("Error in opening:\(String(describing: sqlite3_errmsg(stmt)))")
        }
        return success
    }
    
    func selectAllTask(query:String)
    {
        var db:OpaquePointer?
        var stmt:OpaquePointer?
        let path = getDataBasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stmt, nil) == SQLITE_OK
            {
                taskPatientArray.removeAll()
                taskDoctorArray.removeAll()
                taskWardArray.removeAll()
                while(sqlite3_step(stmt!) == SQLITE_ROW)
                {
                    let taskPatient = sqlite3_column_text(stmt, 0)
                    let tPatient = String(cString: taskPatient!)
                    taskPatientArray.append(tPatient)
                    
                    let taskDoctor = sqlite3_column_text(stmt, 1)
                    let tDoctor = String(cString: taskDoctor!)
                    taskDoctorArray.append(tDoctor)
                    
                    let taskWard = sqlite3_column_text(stmt, 2)
                    let tWard = String(cString: taskWard!)
                    taskWardArray.append(tWard)
                }
            }
            else
            {
                print("Error in prepare:\(sqlite3_step(stmt!))")
            }
        }
        else
        {
            print("Error in open:\(String(describing: sqlite3_errmsg(stmt)))")
        }
    }
    
    func createTable()
    {
        let createQuery = "create table if not exists taskTable(taskPatient,taskDoctor,taskWard)"
        let isSuccess = executeQuery(query: createQuery)
        if isSuccess
        {
            print("create table successfully")
        }
        else
        {
            print("create table not successfully")
        }
    }
}
