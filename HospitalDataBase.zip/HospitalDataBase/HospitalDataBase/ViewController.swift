//
//  ViewController.swift
//  HospitalDataBase
//
//  Created by Shubham Shinde on 15/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var patientArray = [String]()
    var doctorArray = [String]()
    var wardArray = [String]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = viewTable.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.patientLabel.text = patientArray[indexPath.row]
        cell.doctorLable.text = doctorArray[indexPath.row]
        cell.wardLabel.text = wardArray[indexPath.row]
        return cell
    }
    

    
    @IBAction func insertButton(_ sender: UIBarButtonItem) {
        let add = storyboard?.instantiateViewController(withIdentifier: "InsertViewController") as! InsertViewController
        navigationController?.pushViewController(add, animated: true)
    }
    
    @IBOutlet weak var viewTable: UITableView!
    
    @IBAction func editButton(_ sender: UIButton) {
        let edit = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        navigationController?.pushViewController(edit, animated: true)
    }
    override func viewDidLoad() {
        viewTable.delegate = self
        viewTable.dataSource = self
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        let selectQuery = "select taskPatient, taskDoctor, taskWard from taskTable"
        hospitalDB.sharedObject.selectAllTask(query: selectQuery)
        patientArray = hospitalDB.sharedObject.taskPatientArray
        doctorArray = hospitalDB.sharedObject.taskDoctorArray
        wardArray = hospitalDB.sharedObject.taskWardArray
        viewTable.reloadData()
    }

}

