//
//  EditViewController.swift
//  HospitalDataBase
//
//  Created by Shubham Shinde on 15/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {
    

    @IBOutlet weak var editPatient: UITextField!
    
    @IBOutlet weak var editDoctor: UITextField!
    
    @IBOutlet weak var editWard: UITextField!
    
    @IBAction func updateButton(_ sender: UIButton) {
        let updateQuery = "update taskTable set taskPatient = '\(editPatient.text!)' where taskDoctor = '\(editDoctor.text!)'"
        let isSuccess = hospitalDB.sharedObject.executeQuery(query: updateQuery)
            if isSuccess
        {
            print("update: Success")
        }
        else
        {
            print("update: Failed")
        }
    }
    
    @IBAction func deleteButton(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
