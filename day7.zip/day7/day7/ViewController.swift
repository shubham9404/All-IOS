//
//  ViewController.swift
//  day7
//
//  Created by student14 on 26/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var blue: UISlider!
    @IBOutlet weak var green: UISlider!
    @IBOutlet weak var red: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func WTR(_ sender: UISlider) {
        view.backgroundColor = UIColor(displayP3Red: CGFloat(red.value), green: 0, blue: 0, alpha: 1)
    }
    
    @IBAction func WTG(_ sender: Any) {
        view.backgroundColor = UIColor(displayP3Red: 0, green: CGFloat(green.value), blue: 0, alpha: 1)
    }
    
    @IBAction func WTB(_ sender: Any) {
        view.backgroundColor = UIColor(displayP3Red: 0, green: 0, blue: CGFloat(blue.value), alpha: 1)
    }
    
}

