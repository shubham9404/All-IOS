//
//  ViewController.swift
//  MapView
//
//  Created by student14 on 17/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController, UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let go = CLGeocoder()
        go.geocodeAddressString(Text.text!) { (placeMarks, error) in
            let placeMark = placeMarks?.first!
            let point = placeMark?.location?.coordinate
            let span = MKCoordinateSpan(latitudeDelta: 0.01,longitudeDelta: 0.01)
            let region = MKCoordinateRegion(center: point!, span: span)
            let annotation = MKPointAnnotation()
            self.mapview.setRegion(region, animated: true)
            annotation.coordinate = point!
            self.mapview.addAnnotation(annotation)
        }
        return true
    }
    
    @IBOutlet weak var Text: UITextField!
    
    @IBOutlet weak var mapview: MKMapView!
    override func viewDidLoad() {
        Text.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

