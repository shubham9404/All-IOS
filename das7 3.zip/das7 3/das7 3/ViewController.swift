//
//  ViewController.swift
//  das7 3
//
//  Created by student14 on 26/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var saveText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func saveButton(_ sender: UIButton) {
        let defaults = UserDefaults.standard
        defaults.setValue(saveText.text!, forKey: "Message")
    }
    
    
    
    @IBAction func nextButton(_ sender: Any) {
        nextButton.text = UserDefaults.standard.value(forKey: "Message") as! String
    }
}

