//
//  ViewController.swift
//  coreDataDemo2
//
//  Created by Shubham Shinde on 13/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var empno = [String]()
    var empname = [String]()
    var empsalary = [String]()
    var empdepartment = [String]()
    var empcontact = [String]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return empno.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.no.text = empno[indexPath.row]
        cell.name.text = empname[indexPath.row]
        cell.contact.text = empcontact[indexPath.row]
        cell.depatment.text = empdepartment[indexPath.row]
        cell.salary.text = empsalary[indexPath.row]
        return cell
    }
    

    let delegate=UIApplication.shared.delegate as! AppDelegate
    
   

    func readFromCoreData() {
            let context=delegate.persistentContainer.viewContext;

           let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
           //request.predicate = NSPredicate(format: "name = %@", "Nilesh")
          //request.returnsObjectsAsFaults = false
          do {
               let result = try context.fetch(request)
               for data in result as! [NSManagedObject] {
                let str=data.value(forKey: "name") as! String
                print(str)
                let contactNumber=data.value(forKey: "contactNo") as! String
                   print(contactNumber)
               }
            
            
          }
            
           catch {
            
               print(error.localizedDescription)
           }
           
    //        This will pr
            
    //        do{
    //      let  result = try request.execute()
    //            for res in result {
    //                print(res)
    //            }
    //
    //        }
    //        catch
    //        {
    //            print(error.localizedDescription)
    //        }
        }
    
    @IBOutlet weak var EmpNo: UITextField!
    
    @IBOutlet weak var EmpName: UITextField!
    
    @IBOutlet weak var EmpContact: UITextField!
    
    @IBOutlet weak var EmpDepartment: UITextField!
    
    @IBOutlet weak var EmpSalary: UITextField!
    
    @IBAction func insertButton(_ sender: UIButton) {
        let context=delegate.persistentContainer.viewContext;

        //let entityDescription=NSEntityDescription .entity(forEntityName: "Employee", in: context);

        let empObject:NSObject=NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context)
        empObject.setValue(self.EmpNo.text, forKey: "employeeNo")
        empObject.setValue(self.EmpName.text, forKey: "name")
        empObject.setValue(self.EmpContact.text, forKey: "contactNo")
        empObject.setValue(self.EmpDepartment.text, forKey: "departmentNo")
        let formater=NumberFormatter()
        let sal=formater.number(from: self.EmpSalary.text!) as! Double
        empObject.setValue(sal, forKey: "salary")
         do
         {
            try context.save()
        }
        catch
        {
            print(error.localizedDescription)
        
        }
        print("Insert:Success")
        let noinput = EmpNo.text
        empno = [noinput!]
        
        let nameinput = EmpName.text
        empname = [nameinput!]
        
        let salaryinput = EmpSalary.text
        empsalary = [salaryinput!]
        
        let departmentinput = EmpDepartment.text
        empdepartment = [departmentinput!]
        
        let contactinput = EmpContact.text
        empcontact = [contactinput!]
        
    }
    
    @IBAction func updateButton(_ sender: UIButton) {
        let context=delegate.persistentContainer.viewContext;
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.returnsObjectsAsFaults = false

        request.predicate = NSPredicate(format: "name = %@", EmpName.text!)

        do
        {
        let result = try context.fetch(request)
            print(result)
            if(result.count>=1)
            {
            let object:NSManagedObject = result.first as! NSManagedObject
                print(object)
                object.setValue(EmpNo.text, forKey:"contactNo")
                try context.save()
            }
        }
        catch
        {
            print(error.localizedDescription)
        }
        print("Update:Success")
       
    }
    
    @IBAction func deleteButton(_ sender: UIButton) {
        let context=delegate.persistentContainer.viewContext;
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.returnsObjectsAsFaults = false
        request.predicate = NSPredicate(format: "name = %@", EmpName.text!)
        do
        {
            let result = try context.fetch(request)
            print(result)
            if(result.count==1)
            {
                let object:NSManagedObject = result.first as! NSManagedObject
                print(object)
                context.delete(object)
               try context.save()
            }
            
        }
        catch
        {
            print(error.localizedDescription)
        }
        print("Delete:Success")
    }
    
    
    @IBOutlet weak var viewTable: UITableView!
    override func viewDidLoad() {
        viewTable.delegate = self
        viewTable.dataSource = self
           super.viewDidLoad()
            readFromCoreData()
           viewTable.dataSource = self
           // Do any additional setup after loading the view.
       }
}

