//
//  TableViewCell.swift
//  coreDataDemo2
//
//  Created by Shubham Shinde on 13/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var no: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var contact: UILabel!
    
    @IBOutlet weak var depatment: UILabel!
    
    @IBOutlet weak var salary: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
