//
//  Botony.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 26/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class Music: BaseViewController {

    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()
    }
    
    
    
}



