//
//  FacultyViewController.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 25/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class Faculty: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet var facultyOutletCollection: [UIButton]!
    
    
    @IBAction func Arts(_ sender: UIButton) {
        facultyOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    
    }
    
    @IBAction func Defence(_ sender: UIButton) {
        let nextdefence = storyboard?.instantiateViewController(withIdentifier: "Defence") as! Defence
        navigationController?.pushViewController(nextdefence, animated: true)
    }
    
    @IBAction func Economics(_ sender: Any) {
        let nexteconomics = storyboard?.instantiateViewController(withIdentifier: "Economics") as! Economics
        navigationController?.pushViewController(nexteconomics, animated: true)
    }
    
    @IBAction func Geography(_ sender: Any) {
        let nextgeography = storyboard?.instantiateViewController(withIdentifier: "Geography") as! Geography
        navigationController?.pushViewController(nextgeography, animated: true)
    }
    
    @IBAction func History(_ sender: Any) {
        let nexthistory = storyboard?.instantiateViewController(withIdentifier: "History") as! History
        navigationController?.pushViewController(nexthistory, animated: true)
    }
    
    @IBAction func English(_ sender: Any) {
        let nextenglish = storyboard?.instantiateViewController(withIdentifier: "English") as! English
        navigationController?.pushViewController(nextenglish, animated: true)
    }
    @IBAction func Marathi(_ sender: UIButton) {
        let nextmarathi = storyboard?.instantiateViewController(withIdentifier: "Marathi") as! Marathi
        navigationController?.pushViewController(nextmarathi, animated: true)
    }
    
    @IBAction func Sanskrit(_ sender: Any) {
        let nextsanskrit = storyboard?.instantiateViewController(withIdentifier: "Sanskrit") as! Sanskrit
        navigationController?.pushViewController(nextsanskrit, animated: true)
    }
    
    @IBAction func Music(_ sender: Any) {
        let nextmusic = storyboard?.instantiateViewController(withIdentifier: "Music") as! Music
        navigationController?.pushViewController(nextmusic, animated: true)
    }
    
    @IBAction func Hindi(_ sender: Any) {
        let nexthindi = storyboard?.instantiateViewController(withIdentifier: "Hindi") as! Hindi
        navigationController?.pushViewController(nexthindi, animated: true)
    }
    
    @IBAction func PoliticalScience(_ sender: Any) {
        let nextpolitical = storyboard?.instantiateViewController(withIdentifier: "Political") as! Political
        navigationController?.pushViewController(nextpolitical, animated: true)
    }
    @IBAction func Psycology(_ sender: Any) {
        let nextpsycology = storyboard?.instantiateViewController(withIdentifier: "Psycology") as! Psycology
        navigationController?.pushViewController(nextpsycology, animated: true)
    }
    
    @IBAction func Sociology(_ sender: Any) {
        let nextsociology = storyboard?.instantiateViewController(withIdentifier: "Sociology") as! Sociology
        navigationController?.pushViewController(nextsociology, animated: true)
    }
    @IBOutlet var facultyOutletCollection2: [UIButton]!
    
    
    @IBAction func Science(_ sender: UIButton) {
        facultyOutletCollection2.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    }
    
    
    @IBAction func Commerce(_ sender: UIButton) {
        let nextp = storyboard?.instantiateViewController(withIdentifier: "CommerceDepartment") as! CommerceDepartment
        navigationController?.pushViewController(nextp, animated: true)
    }
    
    @IBAction func Biotech(_ sender: Any) {
        let nextbiotech = storyboard?.instantiateViewController(withIdentifier: "Biotech") as! Biotech
        navigationController?.pushViewController(nextbiotech, animated: true)
    }
    
    @IBAction func Botony(_ sender: Any) {
        let nextbotony = storyboard?.instantiateViewController(withIdentifier: "Botony") as! Botony
        navigationController?.pushViewController(nextbotony, animated: true)
    }
    
    @IBAction func Chemistry(_ sender: Any) {
        let nextchemistry = storyboard?.instantiateViewController(withIdentifier: "Chemistry") as! Chemistry
        navigationController?.pushViewController(nextchemistry, animated: true)
    }
    
    @IBAction func ComputerIT(_ sender: Any) {
        let nextcomputerit = storyboard?.instantiateViewController(withIdentifier: "ComputerIt") as! ComputerIt
        navigationController?.pushViewController(nextcomputerit, animated: true)
    }
    
    @IBAction func Electronics(_ sender: Any) {
        let nextelectronics = storyboard?.instantiateViewController(withIdentifier: "Electronics") as! Electronics
        navigationController?.pushViewController(nextelectronics, animated: true)
    }
    
    @IBAction func Geographi(_ sender: Any) {
        let nextelgeography = storyboard?.instantiateViewController(withIdentifier: "Geographi") as! Geographi
        navigationController?.pushViewController(nextelgeography, animated: true)
    }
    
    @IBAction func Geology(_ sender: Any) {
        let nextegeology = storyboard?.instantiateViewController(withIdentifier: "Geology") as! Geology
        navigationController?.pushViewController(nextegeology, animated: true)
    }
    
    @IBAction func Math(_ sender: Any) {
        let nextemath = storyboard?.instantiateViewController(withIdentifier: "Mathematics") as! Mathematics
        navigationController?.pushViewController(nextemath, animated: true)
    }
    
    @IBAction func Micro(_ sender: Any) {
        let nextemicro = storyboard?.instantiateViewController(withIdentifier: "microbio") as! microbio
        navigationController?.pushViewController(nextemicro, animated: true)
    }
    
    @IBAction func Physics(_ sender: Any) {
        let nextephy = storyboard?.instantiateViewController(withIdentifier: "Physics") as! Physics
        navigationController?.pushViewController(nextephy, animated: true)
    }
    
    @IBAction func Stat(_ sender: Any) {
        let nextestat = storyboard?.instantiateViewController(withIdentifier: "Statistics") as! Statistics
        navigationController?.pushViewController(nextestat, animated: true)
    }
    @IBAction func Zology(_ sender: Any) {
        let nextezo = storyboard?.instantiateViewController(withIdentifier: "Zology") as! Zology
        navigationController?.pushViewController(nextezo, animated: true)
    }
}
