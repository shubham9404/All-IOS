//
//  Establishment.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 19/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class Establishment: BaseViewController {
    
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view6: UIView!
    @IBOutlet weak var view7: UIView!
    @IBOutlet weak var view8: UIView!
    
    override func viewDidLoad() {
        addSlideMenuButton()
        view3.layer.cornerRadius = 10.0
        view4.layer.cornerRadius = 10.0
        view5.layer.cornerRadius = 10.0
        view6.layer.cornerRadius = 10.0
        view7.layer.cornerRadius = 10.0
        view8.layer.cornerRadius = 10.0
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
