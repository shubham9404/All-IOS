//
//  main.swift
//  Error Handling
//
//  Created by student14 on 11/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import Foundation
enum InputError:Error
{
    case makeMissing
    case milageTooLow(Int)
    case milageTooHigh(Int)
}
func shouldByCar(make:String,milage:Int) throws
{
    guard make.count>0 else
    {
        throw InputError.makeMissing;
    }
    switch milage
    {
    case milage where milage > 100:
        throw InputError.milageTooLow(milage)
    case milage where milage > 10:
        throw InputError.milageTooHigh(milage)
    default:
        print("Bye the car")
    }
}
do
{
    try shouldByCar(make: "Honda", milage: 151)
}
catch InputError.makeMissing
{
    print("Make Name Missing")
}
catch let InputError.milageTooHigh(x) where x > 150
{
    print("Milage Too way,way high!")
}
catch
{
    print("\(error)")
}
