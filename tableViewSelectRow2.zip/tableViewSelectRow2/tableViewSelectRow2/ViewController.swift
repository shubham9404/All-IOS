//
//  ViewController.swift
//  tableViewSelectRow2
//
//  Created by Shubham Shinde on 20/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fname.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value2, reuseIdentifier: "cell")
        cell.textLabel?.text = fname[indexPath.row]
        cell.detailTextLabel?.text = sname[indexPath.row]
        return cell
    }
    
    var fname = ["Shubhma","Dinesh","Mohit","Mahesh","Sachin","Nitin"]
    var sname = ["Shinde","Shinde","Shinde","Shinde","Shinde","Shinde"]
    
    @IBOutlet weak var viewTable: UITableView!
    override func viewDidLoad() {
        viewTable.delegate = self
        viewTable.dataSource = self
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = viewTable.cellForRow(at: indexPath)!
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        next.lname = (cell.textLabel?.text)!
        next.lsname = (cell.detailTextLabel?.text)!
        navigationController?.pushViewController(next, animated: true)
    }


}

