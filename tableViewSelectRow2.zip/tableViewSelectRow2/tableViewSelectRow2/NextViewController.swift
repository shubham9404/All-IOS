//
//  NextViewController.swift
//  tableViewSelectRow2
//
//  Created by Shubham Shinde on 20/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {

    var lname = String()
    var lsname = String()
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var surname: UILabel!
    override func viewDidLoad() {
        name.text = lname
        surname.text = lsname
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
