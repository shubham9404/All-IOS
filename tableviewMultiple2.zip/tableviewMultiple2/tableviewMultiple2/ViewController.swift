//
//  ViewController.swift
//  tableviewMultiple2
//
//  Created by student14 on 05/09/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    var selectedsubjects = [String]()
    var subjectArray = ["Math", "Electronics", "Stat", "IT", "CS", "Physics"]
    var subjectArray2 = ["Math", "Electronics", "Stat", "IT", "CS", "Physics"]
    var subjectArray3 = ["Math", "Electronics", "Stat", "IT", "CS", "Physics"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return subjectArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        //cell.accessoryType = .detailDisclosureButton
        cell.textLabel?.text = subjectArray[indexPath.row]
        cell.detailTextLabel?.text = subjectArray2[indexPath.row]
        //cell.textLabel?.text = subjectArray3[indexPath.row]
        cell.accessoryType = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! UITableViewCell
        if cell.accessoryType == .checkmark
        {
            cell.accessoryType = .none
            let index = selectedsubjects.index(of:(cell.textLabel?.text!)!)
            selectedsubjects.remove(at: index!)
            print(selectedsubjects)
        }
        else
        {
            selectedsubjects.append((cell.textLabel?.text!)!)
            print(selectedsubjects)
            cell.accessoryType = .checkmark
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func nextButton(_ sender: UIButton) {
        
        let nextp = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        nextp.NextselectedSubject = selectedsubjects
        navigationController?.pushViewController(nextp, animated: true)
        
    }
}

