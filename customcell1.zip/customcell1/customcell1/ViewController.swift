//
//  ViewController.swift
//  customcell1
//
//  Created by student14 on 10/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    let firstNameArray = ["Good","Good","Good","Good"]
    
    let lastNameArray = ["Morning","Morning","Morning","Morning"]
    let lastNameArray2 = ["Shinde","Saindane","More","Sonawane"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return firstNameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.fistName.text = firstNameArray[indexPath.row]
        cell.lastName.text = lastNameArray[indexPath.row]
        cell.lastName2.text = lastNameArray2[indexPath.row]
        return cell
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

