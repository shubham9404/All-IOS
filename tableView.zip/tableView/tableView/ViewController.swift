//
//  ViewController.swift
//  tableView
//
//  Created by student14 on 27/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    var friendsArray = ["Shubham","Ptiyanka","Pratik","Neha","Varsha","Ankita","Nikhil","Akshay","Swami"]
    
    var relativesArray = ["Aatya","Aaba","Mummy","Dada","Me","Didi"]
    
    var imageArray = ["ball.png","east.png","west.png","south.png","north,png","north_east.png","north_west.png","south_east.png","south_west.png","zoom_in.png","zoom_out.png","ball.png","east.png","west.png","south.png"]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
        return friendsArray.count
        }
        else
        {
            return relativesArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.imageView?.image = UIImage(named: imageArray[indexPath.row])
        if indexPath.section == 0
        {
        cell.textLabel?.text = friendsArray[indexPath.row]
            cell.detailTextLabel?.text = "friend"
        }
        else
        {
            cell.textLabel?.text = relativesArray[indexPath.row]
            cell.detailTextLabel?.text = "family"
        }
        return cell 
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        next.name = cell!.textLabel!.text!
        navigationController?.pushViewController(next, animated: true)
        print(cell!.textLabel!.text!)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }


}

