//
//  ViewController.swift
//  FireBase
//
//  Created by Shubham Shinde on 07/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit
import Firebase
import FirebaseCore
import FirebaseDatabase
class ViewController: UIViewController {

    @IBOutlet weak var courseName: UITextField!
    
    @IBOutlet weak var courseDuration: UITextField!
    
    @IBOutlet weak var courseFees: UITextField!
    
   
    @IBAction func saveButton(_ sender: UIButton) {
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController")as!NextViewController
        self.navigationController?.pushViewController(next, animated: true)
    }
    
    @IBAction func nextButton(_ sender: Any) {
        ref = Database.database().reference()
        courseDic.setValue(courseName.text!, forKey: "Name")
        courseDic.setValue(courseDuration.text!, forKey: "Duration")
        courseDic.setValue(courseFees.text!, forKey: "Fee")
        
        
        ref.child("courses").childByAutoId().setValue(courseDic){  (error , reference)
            in
            
            if (error != nil)
            {
                print("Failed to Insert:\(error!.localizedDescription)")
            }
            else
            {
                print("Insert:Success")
            }
        }
    }
    
   var ref: DatabaseReference!
    var courseDic = NSMutableDictionary()
    
    override func viewDidLoad() {
        FirebaseApp.configure()
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

