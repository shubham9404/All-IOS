//
//  ViewController.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 12/02/21.
//  group.com.dropouts.TableViewCell-To-Widgets

import UIKit



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    private var dataSource = RememberDataSource()
    var deleteItem:((jobData) -> Void)?
    var updateItem:((jobData) -> Void)?
    var newItem:((jobData) -> Void)?
    var switchPrimary:((jobData) -> Void)?
    var items: jobData?
    
    var datas = [jobData]()
    let store = JSONStore()
    
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var ageTxt: UITextField!
    @IBOutlet weak var dataTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.datas = store.loadItems()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = dataTableView.dequeueReusableCell(withIdentifier: "cell") as! DataTableViewCell
        let data = datas[indexPath.row]
        cell.nameLable.text = data.name
        cell.ageLable.text = data.age
       // print(cell.nameLable.text!, cell.ageLable.text!)
       // print("Array Data:\(data)")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = dataTableView.cellForRow(at: indexPath)! as! DataTableViewCell
        nameTxt.text = cell.nameLable.text
        ageTxt.text = cell.ageLable.text
        print(indexPath)
    }
    
    @IBAction func setButton(_ sender: UIButton) {
        items?.isPrimary.toggle()
        switchPrimary?(items!)
    }
    
    @IBAction func saveButton(_ sender: UIButton) {
        let nname = nameTxt.text!
        let aage = ageTxt.text!
        
        let dataobject = jobData(name: nname, age: aage)
        //print(dataobject)
      //  datas.append(dataobject)
        newItem(item: dataobject)
//        newItem(item: dataobject)
        self.dataTableView.reloadData()
    }
    
    @IBAction func updateButton(_ sender: Any) {
        
        updateItem = updateItemss
        
        if let updateItem = updateItem, var item = items {
            item.name = nameTxt.text ?? ""
            item.age = ageTxt.text ?? ""
            updateItem(item)
        }
    }
    
    @IBAction func deleteButton(_ sender: UIButton) {
        deleteItem?(items!)
    }
    
    func newItem(item: jobData) {
        datas.append(item)
        store.saveItems(items: datas)
        print("save")
    }
    
    func updateItems(item: jobData) {
        let foundIndex = datas.firstIndex {$0.id == item.id}
        if let foundIndex = foundIndex {
            datas[foundIndex] = item
            store.saveItems(items: datas)
            print("update")
        }
    }
    
    func updateItemss(item: jobData) {
        dataSource.updateItem(item: item) { indexPath in
            dataTableView.reloadRows(at: [indexPath], with: .automatic)
        }
    }
    
    func deleteItem(item: jobData) {
        dataSource.deleteItem(item: item) { indexPath in
            dataTableView.deleteRows(at: [indexPath], with: .none)
        }
        print("delete")
    }
    
    func savePrimary(item: jobData) {
        let newPrimary = PrimaryItem(primaryItem: item)
        newPrimary.storeItem()
        print("set")
    }
}


