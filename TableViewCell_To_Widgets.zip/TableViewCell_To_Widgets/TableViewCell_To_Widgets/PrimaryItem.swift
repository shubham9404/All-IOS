//
//  PrimaryItem.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 16/02/21.
//

import SwiftUI
import WidgetKit

struct PrimaryItem {
    @AppStorage("rememberItem", store: UserDefaults(suiteName: "group.com.dropouts.TableViewCell-To-Widgets")) var primaryData: Data = Data()
    let primaryItem: jobData
    
    func storeItem() {
        let encoder =  JSONEncoder()
        guard let data = try? encoder.encode(primaryItem) else {
            print("Coild not encode data")
            return
        }
        primaryData = data
        WidgetCenter.shared.reloadAllTimelines()
        print(primaryData)
    }
}
