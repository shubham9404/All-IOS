//
//  DataTableViewCell.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 12/02/21.
//

import UIKit

class DataTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var ageLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
