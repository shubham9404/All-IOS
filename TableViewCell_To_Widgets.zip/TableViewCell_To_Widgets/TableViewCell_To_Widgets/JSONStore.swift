//
//  JSONStore.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 18/02/21.
//

import Foundation


class JSONStore {
    
    func loadItems() -> [jobData] {
        var str: [jobData] = []
        let url = self.getDocumentDirectory().appendingPathComponent("shubham.json")
        do {
            let itemData = try Data(contentsOf: url)
            str = try JSONDecoder().decode([jobData].self, from: itemData)
            try itemData.write(to: url, options: .atomicWrite)
        } catch {
            print(error.localizedDescription)
        }
        print("file create successfully")
        return str
    }
    
    func saveItems(items:[jobData]) {
        let encoder = JSONEncoder()
        let url = self.getDocumentDirectory().appendingPathComponent("shubham.json")
   do {
     let itemData = try encoder.encode(items)
     encoder.outputFormatting = .prettyPrinted
     try itemData.write(to: url, options: .atomicWrite)
   } catch let error {
     print(error)
   }
        print("Data save in JSON successfully")
    }
    
    func getDocumentDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(paths)
        return paths[0]
    }
}
