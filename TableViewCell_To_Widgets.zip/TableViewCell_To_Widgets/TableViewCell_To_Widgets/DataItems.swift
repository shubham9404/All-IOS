//
//  DataItems.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 16/02/21.
//

import Foundation

//Data Variables
struct jobData: Codable {
    var id = UUID()
    var name: String
    var age: String
    var isPrimary = false
}
