//
//  Functions.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 17/02/21.
//

import UIKit


class RememberDataSource: NSObject {
    
    let store = JSONStore()
    var rememberItems:[jobData] = []
    
//    override init() {
//        // Load Items from Storage
//        self.rememberItems = store.loadItems()
//    }
    
//    func newItem(item: jobData) {
//        rememberItems.append(item)
//        store.saveItems(items: rememberItems)
//    }
    
    func updateItem(item: jobData, completion: (IndexPath) -> Void) {
        let foundIndex = rememberItems.firstIndex {$0.id == item.id}
        if let foundIndex = foundIndex {
            rememberItems[foundIndex] = item
            store.saveItems(items: rememberItems)
//            let indexpath = IndexPath.init(item: foundIndex, section: 0)
//            if item.isPrimary {
//                savePrimary(item: item)
//            }
//            completion(indexpath)
        }
    }
    
    func deleteItem(item: jobData, completion: (IndexPath) -> Void) {
        let foundIndex = rememberItems.firstIndex {$0.id == item.id}
        if let foundIndex = foundIndex {
            rememberItems.remove(at: foundIndex)
            // Store Items
            store.saveItems(items: rememberItems)
            let indexPath = IndexPath.init(item: foundIndex, section: 0)
            completion(indexPath)
        }
    }
    
    func savePrimary(item: jobData) {
        let newPrimary = PrimaryItem(primaryItem: item)
        newPrimary.storeItem()
    }
    
    func witchPrimary(item: jobData, completion: ([IndexPath]) -> Void) {
        var indexPaths: [IndexPath] = []
        let oldIndex = rememberItems.firstIndex { $0.isPrimary}
        if let oldIndex = oldIndex {
            rememberItems[oldIndex].isPrimary = false
            let oldIndexPath = IndexPath.init(item: oldIndex, section: 0)
            indexPaths.append(oldIndexPath)
            let newIndex = rememberItems.firstIndex { $0.id == item.id }
            if let newIndex = newIndex {
                let newIndexPath = IndexPath.init(item: newIndex, section: 0)
                indexPaths.append(newIndexPath)
            }
            store.saveItems(items: rememberItems)
            completion(indexPaths)
        }
    }
}

