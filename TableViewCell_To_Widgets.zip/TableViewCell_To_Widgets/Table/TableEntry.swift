//
//  TableEntry.swift
//  TableViewCell_To_Widgets
//
//  Created by Shubham Shinde on 16/02/21.
//

import WidgetKit


struct SimpleEntry: TimelineEntry {
    let date: Date
    let dataItems: jobData
}
