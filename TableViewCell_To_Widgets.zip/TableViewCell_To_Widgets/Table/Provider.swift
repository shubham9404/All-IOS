//
//  Provider.swift
//  TableExtension
//
//  Created by Shubham Shinde on 16/02/21.
//

import WidgetKit
import SwiftUI

struct Provider: TimelineProvider {
    
    @AppStorage("rememberItem", store: UserDefaults(suiteName: "group.com.dropouts.TableViewCell-To-Widgets")) var primaryData: Data = Data()
    
    typealias Entry = SimpleEntry
    func placeholder(in context: Context) -> SimpleEntry {
        let rememberItem = jobData(name: "Shubham", age: "23")
        return SimpleEntry(date: Date(), dataItems: rememberItem)
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> ()) {
//        guard let rememberItem = try? JSONDecoder().decode(jobData.self, from: primaryData) else {
//            print("Unable to decode primary item")
//            return
//        }
        let entry = SimpleEntry(date: Date(), dataItems: jobData(name: "Shubham", age: "23"))
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        guard let rememberItem = try? JSONDecoder().decode(jobData.self, from: primaryData) else {
            print("Unable to decode primary item")
            return
        }
        let entry = SimpleEntry(date: Date(), dataItems: rememberItem)
        let timeline = Timeline(entries: [entry], policy: .never)
        completion(timeline)
    }
}
