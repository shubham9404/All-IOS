//
//  Table.swift
//  Table
//
//  Created by Shubham Shinde on 16/02/21.
//

import WidgetKit
import SwiftUI


struct TableEntryView : View {
    var entry: Provider.Entry
    @Environment(\.widgetFamily) var Family

    var body: some View {
        if Family == .systemSmall {
            SmallWidget(entry: entry)
        } else {
            MediumWidget(entry: entry)
        }
    }
}

struct SmallWidget: View {
    var entry: Provider.Entry
    
    var body: some View {
        HStack {
            Text(entry.dataItems.name)
            Text(entry.dataItems.age)
        }
    }
}

struct MediumWidget: View {
    var entry: Provider.Entry
    
    var body: some View {
        HStack {
            Text(entry.dataItems.name)
            Text(entry.dataItems.age)
        }
    }
}
@main
struct Table: Widget {
    let kind: String = "Table"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            TableEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct Table_Previews: PreviewProvider {
    static let rememberItem = jobData(name: "Shubham", age: "23")
    static var previews: some View {
        Group {
            TableEntryView(entry: SimpleEntry(date: Date(), dataItems: jobData(name: "Shubham", age: "23")))
                .previewContext(WidgetPreviewContext(family: .systemSmall))
            TableEntryView(entry: SimpleEntry(date: Date(), dataItems: jobData(name: "Shubham", age: "23")))
                .previewContext(WidgetPreviewContext(family: .systemMedium))
        }
    }
}
