//
//  ViewController.swift
//  SMS6
//
//  Created by student14 on 23/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func but(_ sender: Any) {
    }
    
}

