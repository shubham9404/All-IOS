//
//  ViewController.swift
//  SMS3
//
//  Created by student14 on 22/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labtext: UILabel!
    @IBOutlet weak var nametext: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttext(_ sender: Any) {
        labtext.text = nametext.text
    }
    
    @IBAction func nextbut(_ sender: Any) {
        let nextp = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        nextp.name = nametext.text!
        navigationController?.pushViewController(nextp, animated: true)
    }
}

