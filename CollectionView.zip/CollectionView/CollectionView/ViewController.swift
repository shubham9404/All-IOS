//
//  ViewController.swift
//  CollectionView
//
//  Created by student14 on 10/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    fileprivate let numberOfItems = 3
    
   let inset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
    var numberArray = [String]()
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return numberArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.numberLable.text = numberArray[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let totalSpace = inset.left+inset.right + CGFloat(10*(numberOfItems-1))
        let totalWidth = collectionView.bounds.width - totalSpace
        let width = totalWidth / CGFloat(numberOfItems)
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        return inset
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    {
        return inset.left
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 1...30
        {
            numberArray.append(String(i))
            print(numberArray)
        }
        // Do any additional setup after loading the view, typically from a nib.
    }


}

