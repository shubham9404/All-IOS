//
//  ViewController.swift
//  SMS4
//
//  Created by student14 on 23/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBOutlet weak var ballImage: UIImageView!
    @IBAction func animateBall(_ sender: UIButton) {
        switch sender.tag
        {
        case 101:
            animateSouthWest()
            
        case 102:
            animateNorth()
            
        case 103:
            animateSouthEast()
            
        case 104:
            animateWest()
            
        case 106:
            animateEast()
            
        case 107:
            animateNorthWest()
            
        case 108:
            animateSouth()
            
        case 109:
            animateNorthEast()
            
        default:
            ""
        }
    }
    
    func animateNorth()
    {
        if(self.ballImage.frame.origin.y >= 0)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x, y: self.ballImage.frame.origin.y-100, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("North Animation Completed")
        }
        }
    }
    
    func animateSouth()
    {
        if(self.ballImage.frame.origin.y <= 500)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x, y: self.ballImage.frame.origin.y+100, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("South Animation Completed")
        }
        }
        }
    
    func animateWest()
    {
        if(self.ballImage.frame.origin.x >= 0)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x-100, y: self.ballImage.frame.origin.y, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("West Animation Completed")
        }
        }
    }
    
    func animateEast()
    {
        if(self.ballImage.frame.origin.x <= 300)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x+100, y: self.ballImage.frame.origin.y, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("East Animation Completed")
        }
        }
    }
    
    func animateSouthWest()
    {
        if(self.ballImage.frame.origin.y <= 500) && (self.ballImage.frame.origin.x >= 0)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x-50, y: self.ballImage.frame.origin.y-50, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("SouthWest Animation Completed")
        }
        }
        }
    }
    
    func animateSouthEast()
    {
        if(self.ballImage.frame.origin.x <= 300) && (self.ballImage.frame.origin.x <= 500)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x+50, y:self.ballImage.frame.origin.y-50, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("SouthEast Animation Completed")
        }
        }
    }
    
    func animateNorthWest()
    {
        if(self.ballImage.frame.origin.x >= 0) && (self.ballImage.frame.origin.y >= 0)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x-50, y: self.ballImage.frame.origin.y+50, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("NorthWest Animation Completed")
        }
        }
    }
    
    func animateNorthEast()
    {
        if(self.ballImage.frame.origin.x <= 300) && (self.ballImage.frame.origin.y >= 0)
        {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            
            
            self.ballImage.frame = CGRect(x: self.ballImage.frame.origin.x+50, y: self.ballImage.frame.origin.y+50, width: self.ballImage.bounds.width, height: self.ballImage.bounds.height)
        }) { (true) in
            print("NorthEast Animation Completed")
        }
        }
    }
    






