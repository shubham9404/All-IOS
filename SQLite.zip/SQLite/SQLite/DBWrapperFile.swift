//
//  DBWrapperFile.swift
//  SQLite
//
//  Created by student14 on 19/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import Foundation
import SQLite3
class DBWrapper
{
    var taskNameArray = [String]()
    var taskIDArray = [String]()
    static let sharedObject = DBWrapper()
    
    func getDatabasePath()->String
    {
        let dir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = dir.first!
        return path+"mayDatabase.sqlite"
    }
    func executeQuery(query:String)->Bool
    {
        var success = false
        var db:OpaquePointer?
        var stm:OpaquePointer?
        let path = getDatabasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stm, nil) == SQLITE_OK
            {
                if(sqlite3_step(stm)) == SQLITE_DONE
                {
                    success = true
                    sqlite3_finalize(stm!)
                    sqlite3_close(db)
                }
            }
            else
                {
                    print("Error in prepare:\(sqlite3_step(stm))")
                }
        }
        else
        {
            print("Error in opening:\(String(describing: sqlite3_errmsg(stm)))")
        }
        return success
    }
    
    func selectAllTask(query:String)
    {
        
        var db:OpaquePointer?
        var stmt:OpaquePointer?
        let path = getDatabasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stmt, nil) == SQLITE_OK
            {
                taskNameArray.removeAll()
                taskIDArray.removeAll()
                while(sqlite3_step(stmt)) == SQLITE_ROW
                {
                    let taskName = sqlite3_column_text(stmt, 1)
                    let tName = String(cString: taskName!)
                    taskNameArray.append(tName)
                    
                    let taskID = sqlite3_column_text(stmt, 0)
                    let tID = String(cString: taskID!)
                    taskIDArray.append(tID)
                }
                print(taskNameArray)
                print(taskIDArray)
            }
            else
            {
                print("Error in prepare:\(sqlite3_step(stmt))")
            }
        }
        else
        {
            print("Error in opening:\(String(describing: sqlite3_errmsg(stmt)))")
        }
    }
    
    func createTable()
    {
            let createQuery = "create table if not exists taskTable(taskID text, taskName text)"
        let isSuccess = executeQuery(query: createQuery)
        if isSuccess
        {
            print("Table creation: Success")
        }
        else
        {
            print("Table creation: Failed")
        }
    }
    

}
