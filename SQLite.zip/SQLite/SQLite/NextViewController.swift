//
//  NextViewController.swift
//  SQLite
//
//  Created by student14 on 19/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {

    

    
    @IBOutlet weak var taskIdText: UITextField!
    
    @IBOutlet weak var taskName: UITextField!
    
    @IBAction func submitButton(_ sender: Any) {
        let insertQuery = "insert into taskTable(taskID,taskName) values ('\(taskIdText.text!)','\(taskName.text!)')"
        let isSuccess = DBWrapper.sharedObject.executeQuery(query: insertQuery)
        if isSuccess
        {
            print("insert: Success")
            navigationController?.popViewController(animated:true)
        }
        else
        {
            print("insert: Failed")
        }
    }
    
}
