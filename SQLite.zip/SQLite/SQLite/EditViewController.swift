//
//  EditViewController.swift
//  SQLite
//
//  Created by student14 on 20/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {
    
    var ID = String()
    var name = String()

    @IBOutlet weak var editID: UITextField!
    
    @IBOutlet weak var editName: UITextField!
    
    override func viewDidLoad() {
        editID.text = ID
        editName.text = name
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func updateData(_ sender: UIButton) {
        let updateQuery = "update taskTable set taskName = '\(editName.text!)' where taskID = '\(editID.text!)'"
        let isSuccess = DBWrapper.sharedObject.executeQuery(query: updateQuery)
            if isSuccess
        {
            print("update: Success")
        }
        else
        {
            print("update: Failed")
        }
    }
    
    @IBAction func deleteData(_ sender: UIButton) {
      let deleteQuery = "delete from taskTable where taskID = '\(editID.text!)' "
        let isSuccess = DBWrapper.sharedObject.executeQuery(query: deleteQuery)
        if isSuccess
        {
            print("delete: Success")
        }
        else
        {
            print("delete: Failed")
        }
    }
    
}


/*let insertQuery = "insert into taskTable(taskID,taskName) values ('\(taskIdText.text!)','\(taskName.text!)')"
let isSuccess = DBWrapper.sharedObject.executeQuery(query: insertQuery)
if isSuccess
{
    print("insert: Success")
}
else
{
    print("insert: Failed")
}
 }*/
