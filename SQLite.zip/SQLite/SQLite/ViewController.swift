//
//  ViewController.swift
//  SQLite
//
//  Created by student14 on 19/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tidArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = tidArray[indexPath.row]
        cell.detailTextLabel?.text = tnameArray[indexPath.row]
        return cell
    }
    
var tnameArray = [String]()
    var tidArray = [String]()
    
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func edit(_ sender: Any) {
        let edit = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        navigationController?.pushViewController(edit, animated: true)
    }
    override func viewDidLoad() {
        
        tableView.delegate = self
        tableView.dataSource = self
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        let selectQuery = "select taskID, taskName from taskTable"
        DBWrapper.sharedObject.selectAllTask(query: selectQuery)
        tidArray = DBWrapper.sharedObject.taskIDArray
        tnameArray = DBWrapper.sharedObject.taskNameArray
        tableView.reloadData()
        
    }

    @IBAction func nextButton(_ sender: UIBarButtonItem) {
        let nextp = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        navigationController?.pushViewController(nextp, animated: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let cell = tableView.cellForRow(at: indexPath)!
        let next = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        next.name = (cell.detailTextLabel?.text)!
        next.ID =  (cell.textLabel?.text)!
        navigationController?.pushViewController(next, animated: true)
    }
}
    

    



