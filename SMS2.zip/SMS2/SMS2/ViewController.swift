//
//  ViewController.swift
//  SMS2
//
//  Created by student14 on 22/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labeln: UILabel!
    @IBOutlet weak var textn: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func butn(_ sender: Any) {
        labeln.text = textn.text
    }
    
    
    @IBAction func nextButton(_ sender: Any) {
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        next.name = textn.text!
        navigationController?.pushViewController(next, animated: true)
    }
    
}

