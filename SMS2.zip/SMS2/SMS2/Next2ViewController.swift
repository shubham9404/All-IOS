//
//  Next2ViewController.swift
//  SMS2
//
//  Created by student14 on 22/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class Next2ViewController: UIViewController {
    var name2 = String()

    override func viewDidLoad() {
        super.viewDidLoad()
leb2.text = name2
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var leb2: UILabel!
    
    
    @IBAction func popButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func popToRoot(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    
    
    @IBAction func popToAny(_ sender: Any) {
        let first = navigationController?.viewControllers[1] as! NextViewController
        navigationController?.popToViewController(first, animated: true)
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
