//
//  NextViewController.swift
//  SMS2
//
//  Created by student14 on 22/08/19.
//  Copyright © 2019 raj. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {
var name = String()
    override func viewDidLoad() {
        super.viewDidLoad()
print(name)
        nextLeb.text = name
        // Do any additional setup after loading the view.
    }
    
   
    
    @IBOutlet weak var nextLeb: UILabel!
    
    @IBAction func Next2(_ sender: Any) {
        let next2 = storyboard?.instantiateViewController(withIdentifier: "Next2ViewController") as! Next2ViewController
    next2.name2 = nextLeb.text!
        navigationController?.pushViewController(next2, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
