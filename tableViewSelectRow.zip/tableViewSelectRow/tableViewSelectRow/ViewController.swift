//
//  ViewController.swift
//  tableViewSelectRow
//
//  Created by Shubham Shinde on 20/01/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fname.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = fname[indexPath.row]
        cell.detailTextLabel?.text = lname[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var viewTable: UITableView!
    
    var fname = ["Shubham","Pratik","Neha","Ankita","Varsha","Swami","Akshay","Pushkar"]
    var lname = ["Shinde","More","Bhadane","Punjabi","Pawar","Saindane","Sonawane","Vinchurkar"]

    override func viewDidLoad() {
        viewTable.dataSource = self
        viewTable.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)!
        let next = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        next.sfname = (cell.textLabel?.text)!
        next.slname = (cell.detailTextLabel?.text)!
        navigationController?.pushViewController(next, animated: true)
    }
}

