//
//  ViewController.swift
//  Detect Location
//
//  Created by student14 on 13/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    
    func startDetecting()
    {
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func detectLocation(_ sender: Any) {
        startDetecting()
    }
    
    func detectButton()
    {
       
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation = locations.last!
        print("latitude = \(currentLocation.coordinate.latitude) and Logitude = \(currentLocation.coordinate.longitude)")
        let span = MKCoordinateSpan(latitudeDelta: 0.01,longitudeDelta: 0.01)
        let region = MKCoordinateRegion(center: currentLocation.coordinate, span: span)
        mapView.setRegion(region, animated: true)
        let annotation = MKPointAnnotation()
        annotation.coordinate = currentLocation.coordinate
        mapView.addAnnotation(annotation)
        let geo = CLGeocoder()
        geo.reverseGeocodeLocation(currentLocation) { (placeMarks, error) in
            let placemark = placeMarks?.first!
            let stat = placemark?.isoCountryCode
            annotation.title = stat
        }
        
    }
}

